# Nevermore promotional preview — text alternative

The first eleven seconds show approved production animation on black. A raven
dives forward; the Midnight Host extends his hand and asks, “Trick or Treat?”;
a chest with one large eye opens its toothed mouth; the Veiled Wraith Bride
raises her hand. Wingbeats, wooden creaks, a bell and soft cloth accompany the
animations. These are the runtime artwork and scene audio, not hardware footage.

The second half shows edited excerpts of the current Windows Raven Simulator
Room capture. The Host asks “Trick or Treat?” again. The toothed chest, Bride and
raven appear over a simulated kitchen. These are arranged review triggers, not a
continuous play session. The last raven excerpt does not show or audibly contain
the voice input.

The final card reads “Nevermore. An invitation after dark.” Physical Raven Prism
has not been verified. No real glasses recording is presented. The 7.25-second
teaser contains the four production animations in the same order and no audio.

Captions identify the two spoken lines and describe important scene sounds.
Timing follows the source cue reports; a final owner listening review is pending.
